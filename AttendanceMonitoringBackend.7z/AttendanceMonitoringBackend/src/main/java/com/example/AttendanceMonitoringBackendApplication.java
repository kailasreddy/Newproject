package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AttendanceMonitoringBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AttendanceMonitoringBackendApplication.class, args);
	}

}
