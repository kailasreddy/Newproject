package com.example.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Salary {
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 private long salary_id;
 private int month;
 private int year;
 private float grossSalary;
 private float lop;
 private float otherTaxes;
 private float netSalary;
 private float totalSalary;
 private float pf;
 
 
 public Salary() {
	
}


public Salary(int month, int year, float grossSalary, float lop, float otherTaxes, float netSalary, float totalSalary,
		float pf) {
	super();
	this.month = month;
	this.year = year;
	this.grossSalary = grossSalary;
	this.lop = lop;
	this.otherTaxes = otherTaxes;
	this.netSalary = netSalary;
	this.totalSalary = totalSalary;
	this.pf = pf;
}


public long getSalary_id() {
	return salary_id;
}


public void setSalary_id(long salary_id) {
	this.salary_id = salary_id;
}


public int getMonth() {
	return month;
}


public void setMonth(int month) {
	this.month = month;
}


public int getYear() {
	return year;
}


public void setYear(int year) {
	this.year = year;
}


public float getGrossSalary() {
	return grossSalary;
}


public void setGrossSalary(float grossSalary) {
	this.grossSalary = grossSalary;
}


public float getLop() {
	return lop;
}


public void setLop(float lop) {
	this.lop = lop;
}


public float getOtherTaxes() {
	return otherTaxes;
}


public void setOtherTaxes(float otherTaxes) {
	this.otherTaxes = otherTaxes;
}


public float getNetSalary() {
	return netSalary;
}


public void setNetSalary(float netSalary) {
	this.netSalary = netSalary;
}


public float getTotalSalary() {
	return totalSalary;
}


public void setTotalSalary(float totalSalary) {
	this.totalSalary = totalSalary;
}


public float getPf() {
	return pf;
}


public void setPf(float pf) {
	this.pf = pf;
}
 

}
